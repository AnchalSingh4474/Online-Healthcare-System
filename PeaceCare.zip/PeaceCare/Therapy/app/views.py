from django.shortcuts import render
from django.core.mail import send_mail


# Create your views here.
def home(request):
    return render(request, 'home.html', {})


def contact(request, name=None):
    if request.method == "POST":
        message_name = request.POST['message-name']
        message_email = request.POST['message-email']
        message_subject = request.POST['message-subject']
        message_message = request.POST['message']

        message_name = "message-name"
        message_subject = "message-subject"
        message_message = "message"
        message_email = "message-email"

        recipients = ['mishtythakur138@gmail.com']

        email_list = [message_name, message_subject, message_message, message_email, recipients]

        return render(request, 'forms/contact.html', {'message_name': message_name})

    else:
        return render(request, 'forms/contact.html', {})
